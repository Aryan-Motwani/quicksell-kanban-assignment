import List from "./List";
import {cards} from './data';
import {data} from './api-data';

import React, { Component } from 'react'

export default class App extends Component {

  componentDidMount() {
    fetch(
"https://api.quicksell.co/v1/internal/frontend-assignment")
        .then((res) => res.json())
        .then((json) => {
            this.setState({
                items: json,
                DataisLoaded: true
            });
            
        })
}

  render() {
    let property = "userId";
    let boards = {};
    
    
    data.tickets.forEach(i => {
      if(boards[i[property.split(" ").join("-")]]){
        boards[i[property.split(" ").join("-")]].push(i);
      }else{
        boards[i[property.split(" ").join("-")]] = [i];
      }
    })

    
    
    return (
      <div className="App">
        <nav>
          <select>
            <option>Display</option>
          </select>
        </nav>
        <div className="main-lists">
          {Object.keys(boards).map(i => {
            return <List title={i} data={boards[i]}/>
          })}
        </div>

      </div>
    )
  }
}

    