import React, { Component } from 'react'

export default class Task extends Component {
    constructor(props){
        super(props);
    }
  render() {
    let {task} = this.props;
    return (
      <div className='task-main'>
        <h5>{task.title}</h5>
        <p>Priority : {task.priority}</p>
        <p>By : {task.userId}</p>
      </div>
    )
  }
}
