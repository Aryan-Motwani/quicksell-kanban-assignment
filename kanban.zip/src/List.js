import Task from "./Task"
import "./list.css"
import React, { Component } from 'react'

export default class List extends Component {
    constructor(props){
        super(props);
    }

  render() {
    let data = this.props.data;
    return (
      <div className="board-main">
        <h1>{this.props.title}</h1>
        {data.map(i => {
            return <Task task={i}/>
        })}
      </div>
    )
  }
}
