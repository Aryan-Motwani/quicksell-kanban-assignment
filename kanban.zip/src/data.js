const cards = [
            {
                title : "Card One",
                labels : {
                    text : "this is one task",
                    priority : "high",
                    user : "aryan",
                    status : "done"
                }
            },
            {
                title : "Card Two",
                labels : {
                    text : "this is second task",
                    priority : "low",
                    user : "jayesh",
                    status : "todo"
                }
            },
            {
                title : "Card One",
                labels : {
                    text : "this is one task",
                    priority : "high",
                    user : "aryan",
                    status : "done"
                }
            },
            {
                title : "Card Two",
                labels : {
                    text : "this is second task",
                    priority : "low",
                    user : "jayesh",
                    status : "todo"
                }
            },
            {
                title : "Fuck",
                labels : {
                    text : "this is second task",
                    priority : "low",
                    user : "manav",
                    status : "todo"
                }
            }
]

export {cards};